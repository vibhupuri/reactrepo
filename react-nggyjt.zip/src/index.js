import React, { Component } from 'react';
import { render } from 'react-dom';
import Hello from './Hello';
import './style.css';
import KanbanBoard from './KanbanBoard'
//test
let cardslist = [
  {
id:1,
title:"Read",
description:"Ishould",
status:"in-progress",
tasks:[]
  },
  {
id:2,
title:"Write",
description:"Ishould",
status:"todo",
tasks:[
  {
 id:1,
 name:"Contact",
 done:true
  },
  {
id:2,
name:"Kanban",
done:false
  },
  {
id:3,
name:"Experiment",
done:false
  }
]
  }
];

class App extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }
  render() {
    return (
      <div>
        <Hello name={this.state.name} />
        <KanbanBoard cards={cardslist}/>
        <p>
          Start editing to see some magic happen :)
        </p>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));
